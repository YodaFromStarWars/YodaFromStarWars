﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
namespace Arduino_UNO_Serial_reader
{
    class Program
    {
        static void Main(string[] args)
        {
            try // Code to run/read data from SerialPort
            {
                SerialPort Port = new SerialPort(); // Initializing serialport
                Port.BaudRate = 115200;
                Port.PortName = "COM7";
                Port.Open();

                for(; ;) // Infinite loop
                {
                    string Line = Port.ReadLine();
                    Console.WriteLine(Line);
                    System.Threading.Thread.Sleep(100); // Millisecond delay between reading of data values
                                        
                }
            }
            catch (Exception error) // Exception if no device is connected to serialport
            {
                Console.WriteLine(error.ToString());
                Console.Read();
            }

            //SerialPort Port = new SerialPort();
            //Port.BaudRate = 9600;
            //Port.PortName = "COM7";
            //if (Port.PortName == null)
            //{

            //    Console.WriteLine("Unable to read from port");
            //}
            //else
            //{

            //    Port.Open();
            //}
            //for(; ;)
            //{
            //    string Line = Port.ReadLine();
            //    if (Line != null)
            //    {
            //        Console.WriteLine(Line);
            //        System.Threading.Thread.Sleep(1000);
            //    }
            //    else
            //    {
            //        Console.WriteLine("No input from port");
            //    }
            //}
        }
    }
}
